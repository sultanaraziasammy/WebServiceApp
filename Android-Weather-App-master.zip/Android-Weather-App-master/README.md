# Android Weather App
This is an Android Weather App that show you how to make HTTP requests using Volley library and load images from links using Glide library.

# Tutorial
I made a tutorial that explain more this source code, you can find it [here](https://marwendoukh.wordpress.com/2017/02/01/consuming-rest-web-service-from-android/) .

# Result
When you launch the App ,it will retrieve weather's condition and change the background image according to current weather

![alt Android weather App](https://marwendoukh.files.wordpress.com/2017/01/android-weather-app.png?w=240&h=350)

# Licence
Feel free to use and modify this source code. 


